package ch06.sec07.exam05;

public class CarExample {
    public static void main(String[] args) {
        // 매개변수로 모델만 받는 생성자
        Car car1 = new Car("자가용");

        // 매개변수로 모델과 컬러를 받는 생성자
        Car car2 = new Car("자가용", "빨강");

        // 매개변수로 모델, 컬러, maxSpeed를 받는 생성자
        Car car3 = new Car("택시", "검정", 200);

        // 출력
        System.out.println("car1.company : " + car1.company);
        System.out.println("car2.company : " + car2.company);
        System.out.println("car2.model : " + car2.model);
        System.out.println("car3.company : " + car3.company);
        System.out.println("car3.model : " + car3.model);
        System.out.println("car3.color : " + car3.color);
        System.out.println("car4.company : " + car3.company); // car4는 car3과 동일하므로 car3을 사용
        System.out.println("car4.model : " + car3.model);
        System.out.println("car4.color : " + car3.color);
        System.out.println("car4.maxSpeed : " + car3.maxSpeed);
    }
}


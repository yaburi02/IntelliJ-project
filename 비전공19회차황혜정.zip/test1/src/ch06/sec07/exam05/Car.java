package ch06.sec07.exam05;

public class Car {
    // 필드 선언
    String company = "현대자동차";
    String model;
    String color;
    int maxSpeed;

    // 모델만 받는 생성자
    Car(String model) {
        this(model, "흰색");  // 기본값인 흰색을 color로 설정하고, 다른 생성자 호출
    }

    // 모델과 컬러를 받는 생성자
    Car(String model, String color) {
        this(model, color, 0);  // 기본값인 0을 maxSpeed로 설정하고, 다른 생성자 호출
    }

    // 모델, 컬러, maxSpeed를 받는 생성자
    Car(String model, String color, int maxSpeed) {
        this.model = model;
        this.color = color;
        this.maxSpeed = maxSpeed;
    }
}

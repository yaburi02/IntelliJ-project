package ch06.sec07.exam04;

public class Car {
    String company = "현대자동차";
    String model;
    String color;
    int maxSpeed;

    public Car() {
        this.model = "기본 모델";
        this.color = "흰색";
        this.maxSpeed = 0;
    }

    public Car(String model) {
        this.model = model;
        this.color = "흰색"; // 기본값
        this.maxSpeed = 0; // 기본값
    }

    public Car(String model, String color) {
        this.model = model;
        this.color = color;
        this.maxSpeed = 0; // 기본값
    }

    public Car(String model, String color, int maxSpeed) {
        this.model = model;
        this.color = color;
        this.maxSpeed = maxSpeed;
    }
}

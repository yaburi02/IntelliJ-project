package ch06.sec07.exam01;

public class CarExample {
    public static void main(String[] args) {
        // 매개변수 생성자 호출
        Car myCar = new Car("그랜저", "검정");
        System.out.println("myCar.model : " + myCar.model);  // 출력: 그랜저
        System.out.println("myCar.color : " + myCar.color);  // 출력: 검정

        // 기본 생성자 호출 불가능 (문제의 조건에 맞춰 기본 생성자 호출 불가)
        // 기본 생성자는 사용하지 않기 위해서 주석 처리하였습니다.
        // Car defaultCar = new Car();  // 이 부분은 사용할 수 없습니다.
    }
}

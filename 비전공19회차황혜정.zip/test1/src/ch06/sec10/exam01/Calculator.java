package ch06.sec10.exam01;

public class CalculatorExample {
    public static void main(String[] args) {
        // 원의 넓이 계산: pi * r * r
        double result1 = 10 * 10 * Calculator.pi; // 반지름이 10일 때 원의 넓이
        System.out.println("result1 : " + result1); // 원의 넓이 출력

        // 10과 5의 합
        int result2 = Calculator.plus(10, 5); // 덧셈
        System.out.println("result2 : " + result2); // 덧셈 결과 출력

        // 10과 5의 차
        int result3 = Calculator.minus(10, 5); // 뺄셈
        System.out.println("result3 : " + result3); // 뺄셈 결과 출력
    }
}

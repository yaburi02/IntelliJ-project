package ch06.sec08.exam01;

public class CalculatorExample {

    // Calculator 클래스 정의
    static class Calculator {
        // 전원을 켜는 메소드
        public void powerOn() {
            System.out.println("전원을 켭니다");
        }

        // 덧셈 메소드
        public int plus(int a, int b) {
            return a + b;
        }

        // 나눗셈 메소드
        public double divide(int a, int b) {
            return (double) a / b;
        }

        // 전원을 끄는 메소드
        public void powerOff() {
            System.out.println("전원을 끕니다");
        }
    }

    public static void main(String[] args) {
        // Calculator 객체 생성
        Calculator myCalc = new Calculator();

        // powerOn() 메소드 호출
        myCalc.powerOn();

        // 덧셈 결과 출력
        int result1 = myCalc.plus(5, 6);
        System.out.println("result1: " + result1);

        // 나눗셈 결과 출력
        int x = 10;
        int y = 4;
        double result2 = myCalc.divide(x, y);
        System.out.println("result2: " + result2);

        // powerOff() 메소드 호출
        myCalc.powerOff();
    }
}

package ch06.sec08.exam02;

public class ComputerExample {

    // Computer 클래스 정의
    static class Computer {
        // sum 메소드: 가변 인자를 받아 합을 구하는 메소드
        public int sum(int... values) {
            int total = 0;
            for (int value : values) {
                total += value;
            }
            return total;
        }
    }

    public static void main(String[] args) {
        // Computer 객체 생성
        Computer myCom = new Computer();

        // sum 메소드 호출 (2개의 값)
        int result1 = myCom.sum(1, 2);
        System.out.println("result1: " + result1);

        // sum 메소드 호출 (4개의 값)
        int result2 = myCom.sum(1, 2, 3, 4);
        System.out.println("result2: " + result2);

        // sum 메소드 호출 (배열을 사용)
        int[] values = {1, 2, 3, 4, 5};
        int result3 = myCom.sum(values);
        System.out.println("result3: " + result3);

        // sum 메소드 호출 (new int[]로 배열 전달)
        int result4 = myCom.sum(new int[]{1, 2, 3, 4, 5});
        System.out.println("result4: " + result4);
    }
}

package ch06.sec08.exam04;

public class CalculatorExample {
    public static void main(String[] args) {

        // Calculator 클래스를 CalculatorExample 내에서 정의
        class Calculator {
            // 정사각형 넓이 계산 (한 변의 길이 * 한 변의 길이)
            public double areaRectangle(double side) {
                return side * side;
            }

            // 직사각형 넓이 계산 (가로 * 세로)
            public double areaRectangle(double width, double height) {
                return width * height;
            }
        }

        // 객체 생성
        Calculator myCalcu = new Calculator();

        // 정사각형의 넓이 구하기
        double result1 = myCalcu.areaRectangle(10);  // 정사각형의 한 변이 10
        System.out.println("정사각형 넓이 = " + result1);  // 결과 출력

        // 직사각형의 넓이 구하기
        double result2 = myCalcu.areaRectangle(10, 20);  // 직사각형의 가로 10, 세로 20
        System.out.println("직사각형 넓이 = " + result2);  // 결과 출력
    }
}

package ch06.sec08.exam03;

public class CarExample {
    public static void main(String[] args) {
        Car myCar = new Car();

        myCar.setGas(5);  // gas를 5로 설정

        // gas가 있으면 주행을 시작하고, 없으면 "gas를 주입하세요" 메시지를 출력
        if (myCar.isLeftGas()) {
            System.out.println("gas가 있습니다");
            System.out.println("출발합니다");
            myCar.run();  // 주행 시작
        } else {
            System.out.println("gas를 주입하세요");  // gas가 없으면 출력
        }
    }
}

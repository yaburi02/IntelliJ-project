package ch06.sec08.exam03;

public class Car {
    int gas;  // gas 필드 선언

    // gas 값을 설정하는 메소드
    void setGas(int gas) {
        this.gas = gas;  // 매개변수로 받은 gas 값을 클래스 필드 gas에 설정
    }

    // gas 필드 값에 따라 true 또는 false를 반환하는 메소드
    boolean isLeftGas() {
        if (gas == 0) {
            System.out.println("gas가 없습니다");
            return false;  // gas가 0이면 false 반환
        } else {
            return true;  // gas가 0이 아니면 true 반환
        }
    }

    // 무한 루프를 돌면서 gas 값을 감소시키고 주행 상태를 출력하는 메소드
    void run() {
        while (true) {
            if (isLeftGas()) {
                // gas가 남아있다면 주행
                System.out.println("달립니다. (gas 잔량: " + gas + ")");
                gas--;  // gas가 1 감소
            } else {
                // gas가 없으면 멈춤
                System.out.println("멈춥니다. (gas 잔량: " + gas + ")");
                break;  // 메소드 종료
            }
        }
    }
}

package ch06.sec09;

public class Car {
    // 필드 선언
    String model;
    int speed;

    // 생성자: 모델을 초기화, speed는 기본값 0
    public Car(String model) {
        this.model = model;
        this.speed = 0;  // 기본값 0
    }

    // speed 필드의 getter 메서드
    public int getSpeed() {
        return speed;
    }

    // speed 필드의 setter 메서드
    public void setSpeed(int speed) {
        this.speed = speed;
    }

    // run() 메소드: 모델과 속도를 출력
    public void run() {
        System.out.println(this.model + "는 달립니다. 시속 " + this.speed + " km/h");
    }
}
